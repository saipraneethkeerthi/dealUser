import React from "react";
import Navbar from "../../shared/components/Navbar";

const Home = (props: any) => {
    return (
        <div>
            <Navbar />
        </div>
    )
}

export default Home;
