import { ActionProps } from "./action.type";

export type DispatchProps = (action: ActionProps) => void;