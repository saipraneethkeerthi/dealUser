export interface ActionProps {
    type: string;
    payload?: any;
}