import { DocumentTypes } from "../enums/documentTypes";

export const DocumentTypesDefinition = {
    [DocumentTypes.BANK_STATEMENT] : "Bank Statement"
}