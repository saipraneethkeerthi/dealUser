export const ApiRoutes = {
    BASE_URL: process.env.REACT_APP_API_BASE_URL,
    USER_LOGIN: "/login"
}
