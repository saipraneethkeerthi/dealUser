export enum PaymentModeTypes {
    CREDIT_CARD = "credit_card",
    CASH = "cash"
}