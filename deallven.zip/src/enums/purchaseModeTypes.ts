export enum PurchaseModeTypes  {
    ONLINE = "online",
    GIZA = "giza"
}