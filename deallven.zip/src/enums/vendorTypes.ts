export enum VendorTypes  {
    ONLINE = "online",
    BOTH = "both",
    INSTORE = "offline"
}