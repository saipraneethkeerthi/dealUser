export enum DocumentTypes {
    BANK_STATEMENT = "bank_statement"
}